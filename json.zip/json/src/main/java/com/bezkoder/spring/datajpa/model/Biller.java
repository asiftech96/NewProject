package com.bezkoder.spring.datajpa.model;

public class Biller {

}
